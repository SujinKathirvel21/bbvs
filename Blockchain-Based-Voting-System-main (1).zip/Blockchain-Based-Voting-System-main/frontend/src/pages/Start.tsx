import React from "react";
import Waiting from "../components/Waiting";

const Start = () => {
  return <Waiting />;
};

export default Start;
