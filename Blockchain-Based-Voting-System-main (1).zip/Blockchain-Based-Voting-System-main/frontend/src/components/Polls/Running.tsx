import React from "react";

const Running = () => {
  return (
    <div className="vote-status-wrapper">
      <div className="running"></div>
    </div>
  );
};

export default Running;
